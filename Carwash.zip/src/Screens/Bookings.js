import { View, Text } from 'react-native'
import React from 'react'

const Bookings = () => {
  return (
    <View>
      <Text>Bookings</Text>
    </View>
  )
}

export default Bookings
import React from 'react';
import { View, Text } from 'react-native';
import { COLORS } from '../Constants/Color';

const Upcoming = () => {
  return (
    <View style={{flex:1}}>
        
      <Text>Upcoming</Text>
    </View>
  );
}

export default Upcoming;

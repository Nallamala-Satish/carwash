import { View, Text } from 'react-native'
import React from 'react'

const Vechiles = () => {
  return (
    <View>
      <Text>Vechiles</Text>
    </View>
  )
}

export default Vechiles
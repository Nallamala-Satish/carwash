export const FONTS = {
    extraBold : 'Poppins-ExtraBold',
    title : 'Poppins-SemiBold',
    SemiBold : 'Poppins-SemiBold',
    Bold : 'Poppins-Bold',
    Medium : 'Poppins-Medium',
    Regular : 'Poppins-Regular',
    LightItalic : 'Poppins-LightItalic'
}
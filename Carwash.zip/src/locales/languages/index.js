export default { 
    en: require('./en.json'), 
    te: require('./te.json') 
}